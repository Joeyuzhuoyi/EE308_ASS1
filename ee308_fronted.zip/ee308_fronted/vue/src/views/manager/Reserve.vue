<template>
  <div>
    <div class="search">
      <el-select v-model="status" placeholder="请选择审核状态" style="width: 200px">
        <el-option label="待审核" value="待审核"></el-option>
        <el-option label="审核通过" value="审核通过"></el-option>
        <el-option label="审核不通过" value="审核不通过"></el-option>
      </el-select>
      <el-button type="info" plain style="margin-left: 10px" @click="load(1)">查询</el-button>
      <el-button type="warning" plain style="margin-left: 10px" @click="reset">重置</el-button>
    </div>

    <div class="table">
      <el-table :data="tableData" stripe>
        <el-table-column prop="id" label="序号编号" width="80" align="center" sortable></el-table-column>
        <el-table-column prop="sitName" label="座位" show-overflow-tooltip></el-table-column>
        <el-table-column prop="libadminName" label="自习室管理员" show-overflow-tooltip></el-table-column>
        <el-table-column prop="studentName" label="预约人" show-overflow-tooltip></el-table-column>
        <el-table-column prop="time" label="操作时间"></el-table-column>
        <el-table-column prop="start" label="使用时间段">
<!--          渲染出数据对象中 start 和 end 属性的值，中间使用“~”连接起来-->
          <template v-slot="scope">
            {{scope.row.start}} ~ {{scope.row.end}}
          </template>
        </el-table-column>
        <el-table-column prop="status" label="预约状态"></el-table-column>
        <el-table-column prop="dostatus" label="使用状态"></el-table-column>

        <el-table-column label="操作" width="180" align="center">
          <template v-slot="scope"><!--scope.row传送记录-->
            <el-button plain type="warning" size="mini" @click="del(scope.row.id)" v-if="user.role === 'STUDENT' && scope.row.status === '待审核'">取消预约</el-button>
            <el-button plain type="warning" size="mini" @click="changeStatus(scope.row, '审核通过')" v-if="user.role !== 'STUDENT' && scope.row.status === '待审核'">通过</el-button>
            <el-button plain type="warning" size="mini" @click="changeStatus(scope.row, '审核不通过')" v-if="user.role !== 'STUDENT' && scope.row.status === '待审核'">不通过</el-button>
            <el-button plain type="warning" size="mini" @click="changeStatus(scope.row, '已结束')" v-if="user.role !== 'STUDENT' && scope.row.dostatus === '使用中'">结束使用</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination
            background
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
    </div>


    <el-dialog title="信息" :visible.sync="fromVisible" width="40%" :close-on-click-modal="false" destroy-on-close>
      <el-form label-width="100px" style="padding-right: 50px" :model="form" :rules="rules" ref="formRef">
        <el-form-item prop="title" label="标题">
          <el-input v-model="form.title" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="content" label="内容">
          <el-input type="textarea" :rows="5" v-model="form.content" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="fromVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>


  </div>
</template>

<script>
export default {
  name: "Reserve",
  data() {
    return {
      tableData: [],  // 所有的数据
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      status: null,
      fromVisible: false,
      form: {},
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      rules: {},
      ids: []
    }
  },
  created() {
    this.load(1)
  },
  methods: {
    changeStatus(row, status) {
      let data = JSON.parse(JSON.stringify(row))
      if ('审核通过' === status) {
        data.dostatus = '使用中'
        data.status = status
      }
      if ('审核不通过' === status) {
        data.dostatus = status
        data.status = status
      }
      if ('已结束' === status) {
        data.dostatus = '已结束'
      }
      this.$request.put('/reserve/update', data).then(res => {
        if (res.code === '200') {
          this.$message.success('操作成功')
          this.load(1)
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    del(id) {   // 单个删除
      this.$confirm('您确定取消预约吗？', '提示', {type: "warning"}).then(response => {
        this.$request.delete('/reserve/delete/' + id).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get('/reserve/selectPage', {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          status: this.status,
        }
      }).then(res => {
        this.tableData = res.data?.list
        this.total = res.data?.total
      })
    },
    reset() {
      this.status = null
      this.load(1)
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    },
  }
}
</script>

<style scoped>

</style>
